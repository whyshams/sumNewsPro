import React from 'react'

const Upload = () => {
  return (
    <div className='d-flex justify-content-center align-items-center'>
          <div className='d-md-block d-none'>
      <iframe
        width="1200"
        height="1080"
        allowfullscreen
        frameBorder="0"
        src="https://studio.pixelixe.com/#api?apiKey=m1hn2PIlcZa89AlSr1EG37YjPlD3&allowUploadOnly=true" >
    </iframe>

      </div>
    
      
   
<div className='d-md-none d-block'>
<iframe
  width="414"
  height="896"
  allowfullscreen
  frameBorder="0"
  src="https://studio.pixelixe.com/mobile/#api?apiKey=m1hn2PIlcZa89AlSr1EG37YjPlD3&allowUploadOnly=true" >
</iframe>

</div>
    </div>
  )
}

export default Upload