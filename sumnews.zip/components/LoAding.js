const LoAding = () => {
    return (
      <div className='col-12 col-md-12  loading  d-flex justify-content-center align-items-center'>
      <div className="multi-ripple">
      <div></div>
      <div></div>
    </div>
    </div>
    )
  }
  
  export default LoAding
