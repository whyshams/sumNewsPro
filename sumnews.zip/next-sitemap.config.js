module.exports = {
    siteUrl: 'https://sumnewsbd.com',
    generateRobotsTxt: true, 
    
  }